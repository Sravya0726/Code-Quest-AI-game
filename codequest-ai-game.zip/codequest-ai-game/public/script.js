function startGame() {
    alert("Game will start now!");
    window.location.href = "rounds.html"; // You can change the target later
  }